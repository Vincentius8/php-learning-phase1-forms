<?php

if($_SERVER ["REQUEST_METHOD"] == "POST"){

    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';

    echo "Your Username is: {$username}" . "<br>";
    echo "Your Email is: {$email}" . "<br>";
}

?>