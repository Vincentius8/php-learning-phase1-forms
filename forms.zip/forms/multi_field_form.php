<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multi Field Form</title>
</head>
<body>
    <form action="multi_field_form.php" method="POST">
        <label for="Fullname">Fullname: </label>
        <input type="text" name="fullname"><br>

        <label for="email">Email: </label>
        <input type="email" name="email"><br>

        <label for="age">Age </label>
        <input type="number" name="age"><br>

        <label for="password">Password: </label>
        <input type="password" name="password"><br>

        <button type="submit">Submit</button>

    </form>
    
</body>
</html>


<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $fullname = trim($_POST['fullname'] ?? '');
    $email =$_POST['email'] ?? '';
    $age = $_POST['age'] ?? '';
    $password = trim($_POST['password'] ?? '');
}


echo "Fullname: {$fullname}" . "<br>";
echo "Email: {$email}" . "<br>";
echo "Age: {$age}" . "<br>";
?>