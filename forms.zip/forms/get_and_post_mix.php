<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action = "get_and_post_mix.php" method="POST/GET">
        <label for="name">Username: </label>
        <input type="text" name="username">

        <label for="email">Email: </label>
        <input type="email" name="email">

        <select name="choose submitter">
            <option value="POST">POST</option>
            <option value="GET">GET</option>

        </select>


        <button type="submit">Submit</button>
    </form>
</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $value =$_POST['value'] ?? '';
    

}


if($_SERVER["REQUEST_METHOD"] == "GET"){
    $username = $_GET['username'] ?? '';
    $email = $_GET['email'] ?? '';
    $value = $_GET['value'] ?? '' ;

}



if($value === "GET"){
     echo "Data gathered using GET method";
}

if($value === "POST"){
     echo "Data gathered using POST method";
}


?>